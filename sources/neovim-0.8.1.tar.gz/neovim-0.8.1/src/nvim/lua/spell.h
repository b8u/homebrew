#ifndef NVIM_LUA_SPELL_H
#define NVIM_LUA_SPELL_H

#include <lauxlib.h>
#include <lua.h>
#include <lualib.h>

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "lua/spell.h.generated.h"
#endif

#endif  // NVIM_LUA_SPELL_H
