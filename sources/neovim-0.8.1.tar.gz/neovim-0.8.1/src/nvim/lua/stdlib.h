#ifndef NVIM_LUA_STDLIB_H
#define NVIM_LUA_STDLIB_H

#include <lua.h>

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "lua/stdlib.h.generated.h"
#endif

#endif  // NVIM_LUA_STDLIB_H
