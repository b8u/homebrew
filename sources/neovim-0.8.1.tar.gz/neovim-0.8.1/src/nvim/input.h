#ifndef NVIM_INPUT_H
#define NVIM_INPUT_H

#include "nvim/vim.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "input.h.generated.h"
#endif
#endif  // NVIM_INPUT_H
