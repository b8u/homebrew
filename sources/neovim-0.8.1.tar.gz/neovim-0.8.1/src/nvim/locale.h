#ifndef NVIM_LOCALE_H
#define NVIM_LOCALE_H

#include "nvim/ex_cmds_defs.h"
#include "nvim/types.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "locale.h.generated.h"
#endif
#endif  // NVIM_LOCALE_H
