#ifndef NVIM_ARGLIST_H
#define NVIM_ARGLIST_H

#include "nvim/eval/typval.h"
#include "nvim/ex_cmds_defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "arglist.h.generated.h"
#endif

#endif  // NVIM_ARGLIST_H
