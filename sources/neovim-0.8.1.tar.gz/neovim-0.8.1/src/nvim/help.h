#ifndef NVIM_HELP_H
#define NVIM_HELP_H

#include <stdbool.h>

#include "nvim/ex_cmds_defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "help.h.generated.h"
#endif
#endif  // NVIM_HELP_H
