#ifndef NVIM_API_DEPRECATED_H
#define NVIM_API_DEPRECATED_H

#include <stdint.h>

#include "nvim/api/private/defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "api/deprecated.h.generated.h"
#endif
#endif  // NVIM_API_DEPRECATED_H
