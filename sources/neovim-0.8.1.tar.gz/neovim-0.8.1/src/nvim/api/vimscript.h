#ifndef NVIM_API_VIMSCRIPT_H
#define NVIM_API_VIMSCRIPT_H

#include "nvim/api/private/defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "api/vimscript.h.generated.h"
#endif
#endif  // NVIM_API_VIMSCRIPT_H
