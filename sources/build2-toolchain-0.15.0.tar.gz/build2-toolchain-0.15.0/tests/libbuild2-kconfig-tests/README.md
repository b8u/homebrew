# libbuild2-kconfig-tests

Tests package for the Kconfig build system module for `build2`.
